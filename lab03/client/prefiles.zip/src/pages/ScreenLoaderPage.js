import React from 'react'
import ScreenLoader from '../components/others/ScreenLoader'

export default function ScreenLoaderPage() {
  return (
    <ScreenLoader/>
  )
}
