import React from 'react'
import FinedUserLayout from '../../components/librarian/dashboard/SideBarContentSection/FinedUserLayout'

export default function FinedUserPage() {
  return (
    <FinedUserLayout />
  )
}
