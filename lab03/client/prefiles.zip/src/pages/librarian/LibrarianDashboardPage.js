import React from 'react'
import LibrarianDashboardLayout from '../../components/librarian/dashboard/LibrarianDashboardLayout'

export default function LibrarianDashboardPage() {
  return (
    <LibrarianDashboardLayout />
  )
}
