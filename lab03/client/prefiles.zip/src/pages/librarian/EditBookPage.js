import React from 'react'
import EditBookLayout from '../../components/librarian/dashboard/SideBarContentSection/EditBookLayout'

export default function EditBookPage() {
  return (
    <EditBookLayout />
  )
}
