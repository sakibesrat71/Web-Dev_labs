import React from 'react'
import AddBookLayout from '../../components/librarian/dashboard/SideBarContentSection/AddBookLayout'

export default function AddBookPage() {
  return (
    <AddBookLayout />
  )
}
