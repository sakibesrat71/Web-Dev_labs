import React from 'react'
import BookStoreLayout from '../../components/librarian/dashboard/SideBarContentSection/BookStoreLayout'

export default function BookStorePage() {
  return (
   <BookStoreLayout />
  )
}
