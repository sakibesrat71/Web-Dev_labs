import React from 'react'
import LibrarianLoginLayout from '../../components/librarian/librarianAuthSection/LibrarianLoginLayout'

export default function LibrarianLoginPage() {
  return (
  <LibrarianLoginLayout />
  )
}
