import React from 'react'
import StudentHistoryLayout from '../../components/librarian/dashboard/SideBarContentSection/StudentHistoryLayout'

export default function StudentHistoryPage() {
  return (
    <StudentHistoryLayout />
  )
}
