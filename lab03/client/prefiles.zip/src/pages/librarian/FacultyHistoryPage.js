import React from 'react'
import FacultyHistoryLayout from '../../components/librarian/dashboard/SideBarContentSection/FacultyHistoryLayout'

export default function FacultyHistoryPage() {
  return (
    <FacultyHistoryLayout />
  )
}
