import React from 'react'
import UserBookFormLayout from '../../components/user/userBookFormSection/UserBookFormLayout'

export default function UserBookFormPage() {
  return (
    <UserBookFormLayout />
  )
}
