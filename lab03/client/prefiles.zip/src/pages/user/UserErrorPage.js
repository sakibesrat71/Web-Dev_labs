import React from 'react'
import UserErrorLayout from '../../components/user/userErrorSection/UserErrorLayout'
export default function UserErrorPage() {
  return (
    <UserErrorLayout/>
  )
}
