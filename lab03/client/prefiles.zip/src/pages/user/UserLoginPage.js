import React from 'react'
import UserLoginFormLayout from '../../components/user/userAuthenticationSection/UserLoginFormLayout'

export default function UserLoginPage() {
  return (
    <UserLoginFormLayout/>
  )
}
