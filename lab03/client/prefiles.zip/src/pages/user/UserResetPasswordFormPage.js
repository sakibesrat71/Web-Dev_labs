import React from 'react'
import UserResetPasswordFormLayout from '../../components/user/userAuthenticationSection/UserResetPasswordFormLayout'

export default function UserResetPasswordFormPage() {
  return (
    <UserResetPasswordFormLayout />
  )
}
