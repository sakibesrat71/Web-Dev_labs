import React from 'react'
import BookBorrowSuccessLayout from '../../components/others/BookBorrowSuccessLayout'

export default function BookBorrowedSuccessPage() {
  return (
    <BookBorrowSuccessLayout />
  )
}
