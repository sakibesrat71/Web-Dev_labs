import React from 'react'
import UserSignUpFormLayout from '../../components/user/userAuthenticationSection/UserSignUpFormLayout'
import { withAuth } from '../../components/user/userAuthenticationSection/withAuth';
 function UserSignUpPage() {
  return (
    <UserSignUpFormLayout />
  )
  
}
export default UserSignUpPage;
