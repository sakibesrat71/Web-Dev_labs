import React from 'react'
import UserHomeLayout from '../../components/user/userHomeSection/UserHomeLayout'

export default function UserHomePage() {
  return (
    
    <UserHomeLayout />
  )
}
