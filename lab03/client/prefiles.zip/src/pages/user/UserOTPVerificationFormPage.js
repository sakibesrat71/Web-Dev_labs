import React from 'react'
import UserOTPVerificationFormLayout from '../../components/user/userAuthenticationSection/UserOTPVerificationFormLayout'

export default function UserOTPVerificationFormPage() {
  return (
    <UserOTPVerificationFormLayout />
  )
}
