import React from 'react'
import UserLibraryLayout from '../../components/user/userLibrarySection/UserLibraryLayout'

export default function UserLibraryPage() {
  return (
   <UserLibraryLayout />
  )
}
