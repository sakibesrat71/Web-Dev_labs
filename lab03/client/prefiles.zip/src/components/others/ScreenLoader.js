import React from 'react'
import ScreenLoaderImage from './ScreenLoaderImage'

export default function ScreenLoader() {
  return (
    <div>

        <ScreenLoaderImage />
        
       

    </div>
  )
}
