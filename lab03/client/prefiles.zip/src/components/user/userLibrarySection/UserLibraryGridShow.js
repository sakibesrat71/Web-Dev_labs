import React from "react";
import UserLibraryCards from "./UserLibraryCards";
import axios from "axios";

export default function UserLibraryGridShow() {
  const [books, setBooks] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);

  React.useEffect(() => {
    axios
      .get("http://localhost:5001/book")
      .then((response) => {
        setBooks(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  return (
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
      {loading ? (
        <div>Loading...</div>
      ) : error ? (
        <div>Error</div>
      ) : (
        books.map((book) => <UserLibraryCards book={book} />)
      )}

    </div>
  );
}
