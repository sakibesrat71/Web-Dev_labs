import React from 'react'

export default function TitleSectionLayout() {
  return (
    <div class="max-w-screen-xl px-4 pb-8 mx-auto lg:pb-16">
    icon
  </div>
  )
}
