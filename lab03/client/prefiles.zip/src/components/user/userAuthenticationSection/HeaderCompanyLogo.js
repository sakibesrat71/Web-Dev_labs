import React from 'react'

export default function HeaderCompanyLogo() {
  return (
    <div>
   
    <h2 class="text-center">Library Management System</h2>
  </div>
  )
}
