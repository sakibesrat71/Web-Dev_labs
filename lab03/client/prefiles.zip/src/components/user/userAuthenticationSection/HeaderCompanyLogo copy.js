import React from 'react'

export default function HeaderCompanyLogo() {
  return (
    <div>
   
    <h2 class="text-center">{"app logo"}</h2>
  </div>
  )
}
