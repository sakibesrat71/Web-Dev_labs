import React from 'react'
export default function UserAuthenticationButtonText({authButtonText}) {
  return (
  <>
  {/* <img src={loginLock}  width="30px" height="30px" alt=""/>  */}
    <span className="ml-3"> {authButtonText} </span></>
  )
}
